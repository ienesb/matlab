
%% Main Bistatic ISAC Script
% This script coordinates all stages of the data-aided bistatic ISAC receiver

addpath('modules');

% Step 1: Initialize parameters
params = init_simulation_params();

% Step 2: Generate OFDM symbols (data + pilots)
[X, pilot_mask] = generate_ofdm_symbols(params);

% Step 3: Generate channel and received signal
[Y, H_true] = generate_channel_and_received_signal(params, X);

% Step 4: Stage 1 - Initial channel estimation via pilots
H_est = initial_channel_estimation(Y, X, pilot_mask, params);

% Step 5: Stage 2 - Data demodulation
X_hat = data_demodulation(Y, H_est, pilot_mask, params);

% Step 6: Stage 3 - Refine channel estimation using data-aided method
H_refined = refine_channel_estimate(Y, X_hat, pilot_mask, params);

% Step 7: Stage 4 - Target detection from refined channel
[delay_doppler_map, peaks] = delay_doppler_detection(H_refined, params);

% Step 8: Evaluation and visualization
evaluate_detection(peaks, params);
visualize_results(delay_doppler_map, H_true);


function [DD_map, peaks] = delay_doppler_detection(H, params)
% 2D FFT-based delay-Doppler detection

DD_map = abs(fftshift(fft2(H))).^2;
threshold = mean(DD_map(:)) + 3*std(DD_map(:));  % crude threshold

[rows, cols] = find(DD_map > threshold);
peaks = [rows, cols];

end

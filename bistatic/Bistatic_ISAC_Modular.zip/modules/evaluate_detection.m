
function evaluate_detection(peaks, params)
% Print detection results (placeholder)

fprintf("Detected %d peaks in delay-Doppler domain.\n", size(peaks, 1));

end

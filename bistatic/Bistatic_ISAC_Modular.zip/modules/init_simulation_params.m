
function params = init_simulation_params()
% Simulation parameters for bistatic ISAC

params.N = 400;                   % Number of OFDM subcarriers
params.M = 60;                    % Number of OFDM symbols
params.fc = 28e9;                 % Carrier frequency
params.delta_f = 120e3;           % Subcarrier spacing
params.BW = params.N * params.delta_f;
params.Tsym = 1 / params.delta_f; % Symbol duration
params.Tcp = 1.16e-6;             % Cyclic prefix duration
params.PT = 10^(20/10) / 1000;    % Transmit power (20 dBm)
params.NT = 8;                    % Number of TX antennas
params.noise_fig = 8;             % Noise figure (dB)
params.N0 = 10^(-174/10) / 1000;  % Noise PSD (W/Hz)
params.snr = 10;                  % SNR in dB
params.sigma2 = 10^(-params.snr/10);

params.K = 2;                     % Number of targets
params.known_data = false;       % Genie-aided or not
params.pilot_ratio = 0.05;       % Fraction of pilots
params.modulation = 'QPSK';      % Data modulation

% Locations (x,y): TX, RX, and 2 targets
params.pT = [0, 0];
params.pR = [50, 0];
params.targets = [56.9, 10; 79.4, 7];
params.velocities = [1.4, -2.2; 2.2, -13.7];
params.rcs_dB = [4.9, 1.5];       % Target RCS in dBsm

end

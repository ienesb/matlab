
function X_hat = data_demodulation(Y, H_est, pilot_mask, params)
% LMMSE data demodulation for data symbols

N = params.N;
M = params.M;
data_mask = ~pilot_mask;
X_hat = zeros(N, M);

H_data = H_est(data_mask);
Y_data = Y(data_mask);

X_hat(data_mask) = (Y_data .* conj(H_data)) ./ (abs(H_data).^2 + params.sigma2);

end


function H_refined = refine_channel_estimate(Y, X_hat, pilot_mask, params)
% Refine the channel estimate using data symbols via matched filtering

H_refined = zeros(size(Y));
H_refined(pilot_mask) = Y(pilot_mask) ./ X_hat(pilot_mask);
H_refined(~pilot_mask) = Y(~pilot_mask) .* conj(X_hat(~pilot_mask));

end
